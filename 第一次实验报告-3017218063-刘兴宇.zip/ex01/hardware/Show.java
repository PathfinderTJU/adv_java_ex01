package adv_java.ex01.hardware;

public interface Show {
	
	public void show();
	
}
