package adv_java.ex01.hardware;

public interface Work {
	
	public void work();
	
}
